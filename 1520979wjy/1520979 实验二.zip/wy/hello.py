import os
from datetime import datetime
from flask import Flask, render_template, session, redirect, url_for
from flask_bootstrap import Bootstrap
from flask_moment import Moment
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired
from flask_sqlalchemy import SQLAlchemy

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hard to guess string'
app.config['SQLALCHEMY_DATABASE_URI'] =\
    'sqlite:///' + os.path.join(basedir, 'data.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

bootstrap = Bootstrap(app)
moment = Moment(app)
db = SQLAlchemy(app)


class Post(db.Model):
    __tablename__ = 'user'
    Uid = db.Column(db.Integer, primary_key=True)
    msg = db.Column(db.String(1024), unique=True, index=True)
    author = db.Column(db.String(1024), unique=False, index=True)
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)

    def __repr__(self):
        return '<User %r>' % self.msg

class PostForm(FlaskForm):
   msg = StringField('What is on your mind?', validators=[DataRequired()])
   author = StringField('author name', validators=[DataRequired()])
   submit = SubmitField('Submit')
    
    

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500


@app.route('/', methods=['GET', 'POST'])
def index():
    form = PostForm()
    posts = Post.query.all()
    if form.validate_on_submit():
        user1 = Post(msg=form.msg.data,author=form.author.data)
        db.session.add(user1)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('index.html', form=form, posts=posts)

    
if __name__ == '__main__':
    app.run(debug=True)
