import unittest
from hello import User
from hello import db

class wjyTest(unittest.TestCase):
    
    def setUp(self):
        db.create_all()

    def tearDown(self):
        db.drop_all()
        
    def test_testUser(self):
        self.user=User('wangjiayi')
        self.assertEqual(self.user.username,'wangjiayi')
    
    def test_testAge(self):
        self.user=User('wangjiayi')
        self.assertEqual(self.user.age,20)
	
    def test_testAge2(self):
        self.user=User('wangjiayi',24)
        self.assertEqual(self.user.age,24)
		
if __name__ == '__main__':
    unittest.main()
