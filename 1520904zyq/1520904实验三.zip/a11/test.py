import unittest
from hello import User
from hello import db

class ZyqTest(unittest.TestCase):
    
    def setUp(self):
        db.create_all()

    def tearDown(self):
        db.drop_all()
        
    def test_creatUser(self):
        self.user=User('zhaoyanqiu')
        self.assertEqual(self.user.username,'zhaoyanqiu')
    
    def test_userAge(self):
        self.user=User('zhaoyanqiu')
        self.assertEqual(self.user.age,20)
	
    def test_userAgeInput(self):
        self.user=User('zhaoyanqiu',21)
        self.assertEqual(self.user.age,21)
		
if __name__ == '__main__':
    unittest.main()
